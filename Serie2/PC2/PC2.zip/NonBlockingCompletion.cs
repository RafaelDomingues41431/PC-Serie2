﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC2
{
    public class NonBlockingCompletion
    {
       /* public void Complete() {

        }
        public Boolean WaitForCompletion()
        {

        }

        public void CompleteAll()
        {

        }*/
    }
}
